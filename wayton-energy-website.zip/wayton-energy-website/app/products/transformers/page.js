export default function Transformers() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Transformers</h1>
      <p>Dry-type, Oil-immersed, High Voltage, Special Transformers</p>
    </div>
  );
}