export default function Products() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Our Products</h1>
      <ul style={{ fontSize: '17px', lineHeight: 2, marginTop: 20 }}>
        <li>Transformers</li>
        <li>Transformer Cores</li>
        <li>EV Chargers</li>
        <li>Energy Storage Systems</li>
      </ul>
    </div>
  );
}