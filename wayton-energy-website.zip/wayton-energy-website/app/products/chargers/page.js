export default function Chargers() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>EV Chargers</h1>
      <p>AC Chargers, DC Fast Chargers, All-in-one Energy Storage Chargers</p>
    </div>
  );
}