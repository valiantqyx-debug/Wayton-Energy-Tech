export default function Cores() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Transformer Cores</h1>
      <p>Amorphous cores, CRGO cores, customized cores</p>
    </div>
  );
}