export default function EnergyStorage() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Energy Storage Systems</h1>
      <p>Commercial & Industrial Storage, Residential Storage, Utility ESS</p>
    </div>
  );
}