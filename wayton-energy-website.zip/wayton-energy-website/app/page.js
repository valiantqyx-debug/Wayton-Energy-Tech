export default function Home() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px', fontFamily: 'Arial, sans-serif' }}>
      <header style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ fontSize: '34px', color: '#0F3460' }}>Wayton Energy Tech Co.,Ltd</h1>
        <p style={{ fontSize: '18px', color: '#555' }}>Professional Energy Solutions & Power Equipment</p>
      </header>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#0F3460' }}>Who We Are</h2>
        <p style={{ lineHeight: 1.7 }}>
          Wayton Energy is a professional provider of transformers, transformer cores, EV chargers, energy storage systems, and customized energy solutions for global clients.
        </p>
      </section>

      <section style={{ marginBottom: '30px' }}>
        <h2 style={{ color: '#0F3460' }}>Our Business</h2>
        <ul style={{ paddingLeft: 20, lineHeight: 1.8 }}>
          <li>Transformers (Dry-type / Oil-immersed / Special)</li>
          <li>Transformer Cores</li>
          <li>EV Chargers (AC / DC / All-in-one)</li>
          <li>Energy Storage Systems (Commercial / Industrial / Residential)</li>
          <li>Custom Energy Solutions & OEM Services</li>
        </ul>
      </section>

      <section style={{ background: '#f1f5f9', padding: '20px', borderRadius: 10 }}>
        <h2 style={{ color: '#0F3460' }}>Contact Us</h2>
        <p>Email: <strong>info@waytonenergy.com</strong></p>
        <p>Website: <strong>https://waytonenergy.com</strong></p>
      </section>
    </div>
  );
}