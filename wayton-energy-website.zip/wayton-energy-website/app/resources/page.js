export default function Resources() {
  return <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}><h1>Resources & Downloads</h1></div>;
}