export default function About() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>About Wayton Energy</h1>
      <p style={{ lineHeight: 1.7, marginTop: 20 }}>
        Wayton Energy Tech Co.,Ltd is a professional manufacturer and solution provider in the global power and energy industry.
      </p>
      <p style={{ lineHeight: 1.7 }}>
        We focus on R&D, production, and sales of power transformers, transformer cores, EV charging equipment, energy storage systems, and customized energy solutions.
      </p>
    </div>
  );
}