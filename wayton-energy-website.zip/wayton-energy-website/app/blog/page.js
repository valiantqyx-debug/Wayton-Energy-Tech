export default function Blog() {
  return <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}><h1>Blog & News</h1></div>;
}