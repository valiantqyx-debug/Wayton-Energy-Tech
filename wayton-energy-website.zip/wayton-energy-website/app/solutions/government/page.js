export default function Government() {
  return <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}><h1>Government Projects</h1></div>;
}