export default function Solutions() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Solutions</h1>
    </div>
  );
}