export default function DataCenters() {
  return <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}><h1>Data Center Power Solutions</h1></div>;
}