export default function OEM() {
  return <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}><h1>OEM Services</h1></div>;
}