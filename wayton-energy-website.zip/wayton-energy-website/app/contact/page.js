export default function Contact() {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '40px 20px' }}>
      <h1 style={{ color: '#0F3460' }}>Contact Us</h1>
      <div style={{ marginTop: 20, fontSize: '16px' }}>
        <p><strong>Email:</strong> info@waytonenergy.com</p>
        <p><strong>Website:</strong> waytonenergy.com</p>
        <p><strong>Business Hours:</strong> Monday - Friday</p>
      </div>
    </div>
  );
}